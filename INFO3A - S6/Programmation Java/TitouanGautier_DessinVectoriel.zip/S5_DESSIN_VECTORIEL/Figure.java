import java.awt.*;

public interface Figure {

    public void draw(Graphics2D g);

}
