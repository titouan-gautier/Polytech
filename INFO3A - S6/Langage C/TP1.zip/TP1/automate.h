//
// Created by titoug on 12/02/24.
//

#ifndef AUTOMATE_H
#define AUTOMATE_H
#include <stdio.h>

int automate(FILE *pFile);


#endif //AUTOMATE_H
