## Compiler

```gcc -o main automate.c stack.c main.c```

## Executer

```./main```