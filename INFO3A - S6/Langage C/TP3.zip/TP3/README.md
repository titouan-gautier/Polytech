# TP3 - Langage C

## Compilation
```
gcc -Wall -o main main.c listeBlocMemoire.c
```

## Execution
```
./main
```

Bonne Correction !