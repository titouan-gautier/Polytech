# Langage C - TP2 #

## Compilation ##

```angular2html
gcc -Wall -o main main.c sort.c test.c comparator.c
```

## Execution ##

```angular2html
./main
```