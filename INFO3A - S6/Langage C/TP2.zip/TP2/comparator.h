//
// Created by titoug on 19/02/24.
//

#ifndef COMPARATOR_H
#define COMPARATOR_H

int sortCroissant(int a, int b);
int sortDecroissant(int a, int b);
int sortEven(int a, int b);

#endif //COMPARATOR_H
