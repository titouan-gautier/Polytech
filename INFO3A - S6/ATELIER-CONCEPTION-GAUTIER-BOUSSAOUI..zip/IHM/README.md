# Rendu projet IHM

Pour une meilleure présentation veuillez passer par ce lien Notion (éditeur de texte ne ligne) :

[Présentation Projet IHM Notion](https://stingy-octave-862.notion.site/Projet-IHM-c0806d32c515488ebce1f48494deb1e8)

Sinon vous pouvez passer par le pdf.

Merci, bonne journée.